<?php 
use app\models\company;
?>


<h1> hello </h1>

 <p>
        This is the Application page.$model->intern_id; </p><p>
        ivide pallathum samabavikendeth aan but ippo onum nadakunilla...
        just got to write some codes
        </p>

<?= $model->intern_id;?>

<?= $model->company_id;?>
