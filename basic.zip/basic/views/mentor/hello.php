<?php

/* @var $this yii\web\View */

use yii\helpers\Html;

$this->title = 'Registration Successful';
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="site-about">
    <h1><?= Html::encode($this->title) ?></h1>

    <p>
        Your registration has been completed.The verification of your details will be completed within 24 hours.
    </p>

    
</div>
