
<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;

/* @var $this yii\web\View */
/* @var $model app\models\Mentor */
/* @var $form yii\widgets\ActiveForm */
?>

<div class="mentor-form">

    <?php $form = ActiveForm::begin(); ?>


    
        
      <?=  $form->field($model, 'Verified')->radioList(['yes' => 'Yes', 'no' => 'No']); ?>

    <div class="form-group">
        <?= Html::submitButton($model->isNewRecord ? 'Create' : 'Verify', ['class' => $model->isNewRecord ? 'btn btn-success' : 'btn btn-primary']) ?>
    </div>

    <?php ActiveForm::end(); ?>

</div>
