<?php

/* @var $this yii\web\View */

$this->title = 'My Yii Application';
?>
<div class="site-index">

    <div class="jumbotron">
        <h1>Congratulations!</h1>

        <p class="lead">You have successfully created your Yii-powered application.</p>

        <p><a class="btn btn-lg btn-success" href="http://www.yiiframework.com">Get started with Yii</a></p>
    </div>

    <div class="body-content">

        <div class="row">
            <div class="col-lg-4">
                

                <h2>Company </h2>

                <p><a class="btn btn-default" href="http://localhost/basic/web/index.php?r=company%2Fcreate">Company registration &raquo;</a></p>
                <p><a class="btn btn-default" href="http://localhost/basic/web/index.php?r=interns%2Fcreate">Create new internship  &raquo;</a></p>
            </div>
            <div class="col-lg-4">
                

                <h2> Mentor </h2>

                <p><a class="btn btn-default" href="http://localhost/basic/web/index.php?r=mentor%2Fcreate">Mentor Registration &raquo;</a></p>
                 <p><a class="btn btn-default" href="http://localhost/basic/web/index.php?r=mentor%2Findex">Mentor Verification &raquo;</a></p>
            </div>
            <div class="col-lg-4">
                

                <h2> Student </h2>

                <p><a class="btn btn-default" href="http://localhost/basic/web/index.php?r=stdent%2Fcreate">Student Registration &raquo;</a></p>
                       <p><a class="btn btn-default" href="http://localhost/basic/web/index.php?r=application%2Fcreate">Application &raquo;</a></p>
            </div>
        </div>

    </div>
</div>
