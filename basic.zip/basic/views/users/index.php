<?php
foreach($users as $user)
{
	echo $user->email.", ".$user->phone."<br>";
}
?>