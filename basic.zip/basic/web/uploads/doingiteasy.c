#include<stdio.h>
void mergesort(int A[],int p,int r)
{	int q;
	if(p<r)
	{
		q=(p+r)/2;
		mergesort(A,p,q);
		mergesort(A,q+1,r);
		merge(A,p,q,r);
	}
}
void merge(int A[],int p,int q,int r)
{
	int n1 = q-p+1;
	int n2 = r-q;
	int i,j,k,L[1000],R[1000];
	for(i=1;i<=n1;i++)
	L[i]=A[p+i-1];
	L[n1+1]=2147483647;
	for(i=1;i<=n2;i++)
	R[i]=A[q+i];
	R[n2+1]=2147483647;
	for(k=p,i=1,j=1;k<=r;k++)
	{
		if(L[i]<R[j])
		{	A[k]=L[i];
			i++;
		}
		else
		{	A[k]=R[j];
			j++;
		}
	}
}


int main()
{
	FILE *fp1, *fp2;
	fp1=fopen("NUMBERS.txt","r");
	if(fp1==NULL)
	{
		printf("\n file not seen\n");
		return 0;
	}
	int A[20000],n=0,i=1,j;
	while(!feof(fp1))
	{	
		if(!fscanf(fp1,"%d",&A[i]))
		{	printf("\n invalid input\n");
			return 0;
		}
		i++;
		n++;
	}i--;n--;
	if(n>10000)
	{	printf("\n file too big\n");
		return 0;
	}
	mergesort(A,1,i-1);
	/*for(j=1;j<i;j++)
	printf("%d ",A[j]);
	printf("\n");*/
	fclose(fp1);
	fp2=fopen("OUTPUTFILE.txt","w");
	for(j=1;j<i;j++)
	{
		fprintf(fp2,"%d\n",A[j]);
	}
	fclose(fp2);
	return 0;
}


