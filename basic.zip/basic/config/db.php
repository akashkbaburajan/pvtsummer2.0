<?php

return [
    'class' => 'yii\db\Connection',
    'dsn' => 'mysql:host=localhost;dbname=doingiteasy',
    'username' => 'root',
    'password' => 'adamallys',
    'charset' => 'utf8',
];
