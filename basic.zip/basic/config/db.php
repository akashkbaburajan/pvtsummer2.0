<?php

return [
    'class' => 'yii\db\Connection',
    'dsn' => 'mysql:host=localhost;dbname=doingiteasy',
    'username' => 'root',
    'password' => 'Ak1$city',
    'charset' => 'utf8',
];
