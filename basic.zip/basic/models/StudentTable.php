<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "student_table".
 *
 * @property integer $company_id
 * @property integer $intern_id
 * @property integer $student_id
 * @property string $student_name
 * @property string $student_email
 * @property string $institute
 * @property integer $phone_no
 * @property string $area_of_interest
 * @property string $resume
 *
 * @property Interns $intern
 * @property Company $company
 */
class StudentTable extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'student_table';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['company_id', 'intern_id', 'student_name', 'student_email', 'institute', 'phone_no', 'area_of_interest', 'resume'], 'required'],
            [['company_id', 'intern_id', 'phone_no'], 'integer'],
            [['area_of_interest'], 'string'],
            [['student_name', 'student_email', 'institute', 'resume'], 'string', 'max' => 100],
            [['intern_id'], 'exist', 'skipOnError' => true, 'targetClass' => Interns::className(), 'targetAttribute' => ['intern_id' => 'intern_id']],
            [['company_id'], 'exist', 'skipOnError' => true, 'targetClass' => Company::className(), 'targetAttribute' => ['company_id' => 'company_id']],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'company_id' => 'Company ID',
            'intern_id' => 'Intern ID',
            'student_id' => 'Student ID',
            'student_name' => 'Student Name',
            'student_email' => 'Student Email',
            'institute' => 'Institute',
            'phone_no' => 'Phone No',
            'area_of_interest' => 'Area Of Interest',
            'resume' => 'Resume',
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getIntern()
    {
        return $this->hasOne(Interns::className(), ['intern_id' => 'intern_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getCompany()
    {
        return $this->hasOne(Company::className(), ['company_id' => 'company_id']);
    }
}
