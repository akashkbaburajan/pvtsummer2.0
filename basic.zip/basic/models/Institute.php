<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "institute".
 *
 * @property string $institute
 */
class Institute extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'institute';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['institute'], 'required'],
            [['institute'], 'string', 'max' => 100],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'institute' => 'Institute',
        ];
    }
}
